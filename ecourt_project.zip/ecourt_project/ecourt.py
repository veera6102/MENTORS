"""
Court Listing Fetcher (Enhanced)
--------------------------------
Fetch court listings from eCourts (mock version for assignment).
Now with robust error handling and clear user feedback.
"""

import requests
from bs4 import BeautifulSoup
import json
import argparse
import datetime
import os
import sys

# ------------------------------
# Configuration
# ------------------------------
BASE_URL = "https://services.ecourts.gov.in/ecourtindia_v6/"
DATA_DIR = os.path.join(os.path.dirname(__file__), "data")

# Ensure data directory exists
os.makedirs(DATA_DIR, exist_ok=True)

# ------------------------------
# Helper Functions
# ------------------------------

def save_json(data, filename):
    """Save data as JSON. Appends if file exists; creates otherwise."""
    path = os.path.join(DATA_DIR, filename)
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            try:
                existing = json.load(f)
            except json.JSONDecodeError:
                existing = []
        if isinstance(existing, list):
            existing.append(data)
        else:
            existing = [existing, data]
        final_data = existing
    else:
        final_data = [data]
    with open(path, "w", encoding="utf-8") as f:
        json.dump(final_data, f, indent=4)
    print(f"✅ Saved file: {path}")
    return path

def validate_case_input(cnr, case_type, case_number, year):
    """Validate input and raise custom errors if invalid."""
    # At least CNR, or all three: type, number, year
    if not cnr:
        if not (case_type and case_number and year):
            msg = (
                "❌ Missing required case identifiers.\n"
                "You must provide either:\n"
                "  --cnr CNR_NUMBER  OR\n"
                "  --type TYPE --number NUMBER --year YEAR\n"
                "Example: --type CR --number 42 --year 2022\n"
            )
            raise ValueError(msg)
    # If CNR is given, validate format
    if cnr and len(cnr) != 16:
        raise ValueError("❌ CNR must be 16 characters long (no spaces or hyphens).")
    # If year given, check valid integer and reasonable
    if year:
        try:
            y = int(year)
            if y < 1900 or y > datetime.date.today().year + 1:
                raise ValueError("❌ Year must be a valid 4-digit number.")
        except Exception:
            raise ValueError("❌ Invalid year; must be numeric.")

def fetch_case_details(cnr=None, case_type=None, case_number=None, year=None, day='today'):
    """Fetch and show case listing details (mock response for assignment)."""
    # Input validation
    validate_case_input(cnr, case_type, case_number, year)
    print(f"\n🔍 Checking case listing for {day.upper()}...\n")

    # Convert day to date
    if day == "today":
        target_date = datetime.date.today()
    elif day == "tomorrow":
        target_date = datetime.date.today() + datetime.timedelta(days=1)
    else:
        raise ValueError("❌ Only 'today' or 'tomorrow' supported for listings.")

    # MOCK response (simulate)
    case_id = cnr or f"{case_type}-{case_number}-{year}"
    case_data = {
        "case_id": case_id,
        "checked_on": str(datetime.datetime.now()),
        "date_checked_for": str(target_date),
        # Simulated output for assignment; set as False if you wish to mock 'not listed'
        "is_listed": True,
        "serial_no": "15",
        "court_name": "Courtroom 2 – Hon’ble Justice R. Verma",
        "status": "Listed for Hearing",
        "pdf_url": "https://example.com/sample_case_order.pdf"
    }

    filename = f"case_{day}.json"
    save_json(case_data, filename)

    # Display to console
    print("📄 Case Details:")
    print(json.dumps(case_data, indent=4))

def download_cause_list(day='today'):
    """Download entire cause list (mock example)."""
    if day not in ("today", "tomorrow"):
        raise ValueError("❌ Only 'today' or 'tomorrow' supported for cause list.")
    print(f"\n📥 Fetching cause list for {day.upper()}...\n")
    target_date = datetime.date.today() if day == "today" else datetime.date.today() + datetime.timedelta(days=1)
    # MOCK data
    cause_list = {
        "date": str(target_date),
        "total_cases": 3,
        "cases": [
            {"serial": 1, "case": "ABC vs XYZ", "court": "Courtroom 1"},
            {"serial": 2, "case": "State vs John", "court": "Courtroom 2"},
            {"serial": 3, "case": "Ravi vs Kumar", "court": "Courtroom 3"}
        ]
    }
    filename = f"cause_list_{day}.json"
    save_json(cause_list, filename)
    print("📘 Cause List:")
    print(json.dumps(cause_list, indent=4))

# ------------------------------
# CLI Interface
# ------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Court Listing Fetcher – Check court listings & cause lists (with error feedback)"
    )
    parser.add_argument("--cnr", help="CNR number of the case (optional)")
    parser.add_argument("--type", help="Case type, e.g., CR, CIVIL")
    parser.add_argument("--number", help="Case number")
    parser.add_argument("--year", help="Case year")
    parser.add_argument("--today", action="store_true", help="Check today's listing")
    parser.add_argument("--tomorrow", action="store_true", help="Check tomorrow's listing")
    parser.add_argument("--causelist", action="store_true", help="Download today's cause list")
    args = parser.parse_args()

    try:
        if args.causelist:
            download_cause_list('today')
        elif args.today:
            fetch_case_details(args.cnr, args.type, args.number, args.year, 'today')
        elif args.tomorrow:
            fetch_case_details(args.cnr, args.type, args.number, args.year, 'tomorrow')
        else:
            print("❗Please specify an action (use --help for options).")
    except ValueError as ve:
        print(str(ve))
        sys.exit(2)
    except Exception as e:
        print(f"⚠️ Unhandled Error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
