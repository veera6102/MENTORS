# src/advanced/oco.py
def place_oco_order(*args, **kwargs):
    raise NotImplementedError("OCO orders are not supported on Binance Futures (only Spot).")