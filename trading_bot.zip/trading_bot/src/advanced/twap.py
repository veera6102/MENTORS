import time
from src.limit_orders import place_limit_order
import logging

logger = logging.getLogger(__name__)

def place_twap_order(symbol: str, side: str, total_quantity: float, price: float, num_slices: int = 5, interval_sec: int = 2):
    """
    Time-Weighted Average Price (TWAP) execution using limit orders.
    Splits total_quantity into num_slices and places orders with delay.
    """
    if num_slices <= 0:
        raise ValueError("num_slices must be > 0")
    if total_quantity <= 0 or price <= 0:
        raise ValueError("Quantity and price must be positive")

    slice_qty = total_quantity / num_slices
    logger.info(f"Starting TWAP: {total_quantity} {symbol} in {num_slices} slices")

    for i in range(num_slices):
        try:
            order = place_limit_order(symbol, side, round(slice_qty, 3), price)
            print(f"[TWAP] Slice {i+1}/{num_slices} placed: {slice_qty} @ {price}")
            if i < num_slices - 1:
                time.sleep(interval_sec)
        except Exception as e:
            logger.error(f"TWAP slice {i+1} failed: {e}")
            raise

    logger.info("TWAP execution completed.")