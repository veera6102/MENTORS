from binance import Client
from config import BINANCE_API_KEY, BINANCE_API_SECRET
import logging

logger = logging.getLogger(__name__)

def place_market_order(symbol: str, side: str, quantity: float):
    """
    Place a MARKET order on Binance Futures Testnet.
    side: 'BUY' or 'SELL'
    """
    try:
        client = Client(BINANCE_API_KEY, BINANCE_API_SECRET, testnet=True)
        order = client.futures_create_order(
            symbol=symbol,
            type='MARKET',
            side=side,
            quantity=quantity
        )
        logger.info(f"Market order placed: {order}")
        return order
    except Exception as e:
        logger.error(f"Market order failed for {symbol}: {e}")
        raise