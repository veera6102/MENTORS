# src/client_manager.py
import os
from binance import Client
from dotenv import load_dotenv

load_dotenv()

def get_testnet_client():
    """Initialize and return a Binance Futures Testnet client."""
    api_key = os.getenv("BINANCE_API_KEY")
    api_secret = os.getenv("BINANCE_API_SECRET")
    
    if not api_key or not api_secret:
        raise ValueError("API key or secret not found in .env file.")
    
    client = Client(api_key, api_secret, testnet=True)
    client.FUTURES_URL = 'https://testnet.binancefuture.com/fapi/v1'
    return client