import logging
import sys
from rich.console import Console
from rich.prompt import Prompt, Confirm
from rich import print as rprint
from src.market_orders import place_market_order
from src.limit_orders import place_limit_order
from src.advanced.twap import place_twap_order

# Setup logging
logging.basicConfig(
    filename='bot.log',
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

console = Console()

def validate_symbol(symbol: str) -> str:
    symbol = symbol.strip().upper()
    if not symbol.endswith('USDT'):
        symbol += 'USDT'
    if len(symbol) < 6 or not symbol.replace('USDT', '').isalpha():
        raise ValueError("Invalid symbol format. Use e.g., BTC, ETH, SOL")
    return symbol

def main():
    console.rule("[bold blue]Simplified Trading Bot - Binance Futures Testnet")
    
    try:
        # Input
        symbol_input = Prompt.ask("Enter symbol (e.g., BTC, ETH)")
        symbol = validate_symbol(symbol_input)

        side = Prompt.ask("Order side", choices=["BUY", "SELL"], default="BUY").upper()
        order_type = Prompt.ask("Order type", choices=["MARKET", "LIMIT", "TWAP"], default="MARKET").upper()

        quantity = float(Prompt.ask("Quantity (e.g., 0.001)"))
        if quantity <= 0:
            raise ValueError("Quantity must be > 0")

        price = None
        if order_type in ["LIMIT", "TWAP"]:
            price = float(Prompt.ask("Price (USDT)"))
            if price <= 0:
                raise ValueError("Price must be > 0")

        # Confirmation
        rprint(f"\n[bold yellow]Review Order:[/bold yellow]")
        rprint(f"Symbol: {symbol}")
        rprint(f"Side: {side}")
        rprint(f"Type: {order_type}")
        rprint(f"Quantity: {quantity}")
        if price: rprint(f"Price: {price}")

        if not Confirm.ask("Confirm order?"):
            rprint("[red]Order cancelled.[/red]")
            return

        # Execute
        if order_type == "MARKET":
            result = place_market_order(symbol, side, quantity)
            rprint("[green]✅ Market order placed successfully![/green]")
        elif order_type == "LIMIT":
            result = place_limit_order(symbol, side, quantity, price)
            rprint("[green]✅ Limit order placed successfully![/green]")
        elif order_type == "TWAP":
            num_slices = int(Prompt.ask("Number of TWAP slices", default="5"))
            place_twap_order(symbol, side, quantity, price, num_slices=num_slices)
            rprint("[green]✅ TWAP execution completed![/green]")

        rprint(f"\n[bold cyan]Order ID: {result.get('orderId') if order_type != 'TWAP' else 'N/A'}[/bold cyan]")

    except KeyboardInterrupt:
        rprint("\n[yellow]Operation cancelled by user.[/yellow]")
    except Exception as e:
        rprint(f"[red]❌ Error: {e}[/red]")
        logging.error(f"CLI Error: {e}")

if __name__ == "__main__":
    main()