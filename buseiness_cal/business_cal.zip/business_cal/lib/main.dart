import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (_) => QuoteProvider(),
      child: const ProductQuoteApp(),
    ),
  );
}

// ==================== MODELS ====================

enum QuoteStatus { draft, sent, accepted }

enum TaxMode { inclusive, exclusive }

class LineItem {
  String id;
  String name;
  double quantity;
  double rate;
  double discount;
  double taxPercent;

  LineItem({
    required this.id,
    this.name = '',
    this.quantity = 1,
    this.rate = 0,
    this.discount = 0,
    this.taxPercent = 0,
  });

  double get subtotal => (rate - discount) * quantity;
  double get taxAmount => subtotal * (taxPercent / 100);
  double get total => subtotal + taxAmount;

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'quantity': quantity,
        'rate': rate,
        'discount': discount,
        'taxPercent': taxPercent,
      };

  factory LineItem.fromJson(Map<String, dynamic> json) => LineItem(
        id: json['id'],
        name: json['name'] ?? '',
        quantity: json['quantity'] ?? 1,
        rate: json['rate'] ?? 0,
        discount: json['discount'] ?? 0,
        taxPercent: json['taxPercent'] ?? 0,
      );
}

class Quote {
  String id;
  String clientName;
  String clientAddress;
  String reference;
  List<LineItem> lineItems;
  QuoteStatus status;
  TaxMode taxMode;
  DateTime createdAt;

  Quote({
    required this.id,
    this.clientName = '',
    this.clientAddress = '',
    this.reference = '',
    List<LineItem>? lineItems,
    this.status = QuoteStatus.draft,
    this.taxMode = TaxMode.exclusive,
    DateTime? createdAt,
  })  : lineItems = lineItems ?? [],
        createdAt = createdAt ?? DateTime.now();

  double get subtotal =>
      lineItems.fold(0, (sum, item) => sum + item.subtotal);
  double get totalTax => lineItems.fold(0, (sum, item) => sum + item.taxAmount);
  double get grandTotal => lineItems.fold(0, (sum, item) => sum + item.total);

  Map<String, dynamic> toJson() => {
        'id': id,
        'clientName': clientName,
        'clientAddress': clientAddress,
        'reference': reference,
        'lineItems': lineItems.map((item) => item.toJson()).toList(),
        'status': status.index,
        'taxMode': taxMode.index,
        'createdAt': createdAt.toIso8601String(),
      };

  factory Quote.fromJson(Map<String, dynamic> json) => Quote(
        id: json['id'],
        clientName: json['clientName'] ?? '',
        clientAddress: json['clientAddress'] ?? '',
        reference: json['reference'] ?? '',
        lineItems: (json['lineItems'] as List?)
                ?.map((item) => LineItem.fromJson(item))
                .toList() ??
            [],
        status: QuoteStatus.values[json['status'] ?? 0],
        taxMode: TaxMode.values[json['taxMode'] ?? 1],
        createdAt: DateTime.parse(json['createdAt']),
      );
}

// ==================== PROVIDER ====================

class QuoteProvider extends ChangeNotifier {
  Quote _currentQuote = Quote(
    id: DateTime.now().millisecondsSinceEpoch.toString(),
    lineItems: [LineItem(id: '1')],
  );
  List<Quote> _savedQuotes = [];

  Quote get currentQuote => _currentQuote;
  List<Quote> get savedQuotes => _savedQuotes;

  QuoteProvider() {
    _loadQuotes();
  }

  void updateClientName(String value) {
    _currentQuote.clientName = value;
    notifyListeners();
  }

  void updateClientAddress(String value) {
    _currentQuote.clientAddress = value;
    notifyListeners();
  }

  void updateReference(String value) {
    _currentQuote.reference = value;
    notifyListeners();
  }

  void toggleTaxMode() {
    _currentQuote.taxMode = _currentQuote.taxMode == TaxMode.inclusive
        ? TaxMode.exclusive
        : TaxMode.inclusive;
    notifyListeners();
  }

  void updateLineItem(String id, {
    String? name,
    double? quantity,
    double? rate,
    double? discount,
    double? taxPercent,
  }) {
    final item = _currentQuote.lineItems.firstWhere((item) => item.id == id);
    if (name != null) item.name = name;
    if (quantity != null) item.quantity = quantity;
    if (rate != null) item.rate = rate;
    if (discount != null) item.discount = discount;
    if (taxPercent != null) item.taxPercent = taxPercent;
    notifyListeners();
  }

  void addLineItem() {
    _currentQuote.lineItems.add(
      LineItem(id: DateTime.now().millisecondsSinceEpoch.toString()),
    );
    notifyListeners();
  }

  void removeLineItem(String id) {
    if (_currentQuote.lineItems.length > 1) {
      _currentQuote.lineItems.removeWhere((item) => item.id == id);
      notifyListeners();
    }
  }

  void updateStatus(QuoteStatus status) {
    _currentQuote.status = status;
    notifyListeners();
  }

  Future<void> saveQuote() async {
    final prefs = await SharedPreferences.getInstance();
    final existing = _savedQuotes.indexWhere((q) => q.id == _currentQuote.id);
    if (existing >= 0) {
      _savedQuotes[existing] = _currentQuote;
    } else {
      _savedQuotes.add(_currentQuote);
    }
    await prefs.setString('quotes', jsonEncode(_savedQuotes.map((q) => q.toJson()).toList()));
    notifyListeners();
  }

  Future<void> _loadQuotes() async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getString('quotes');
    if (data != null) {
      final list = jsonDecode(data) as List;
      _savedQuotes = list.map((item) => Quote.fromJson(item)).toList();
      notifyListeners();
    }
  }

  void createNewQuote() {
    _currentQuote = Quote(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      lineItems: [LineItem(id: '1')],
    );
    notifyListeners();
  }

  void loadQuote(Quote quote) {
    _currentQuote = quote;
    notifyListeners();
  }
}

// ==================== MAIN APP ====================

class ProductQuoteApp extends StatelessWidget {
  const ProductQuoteApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Product Quote Builder',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF6366F1),
          brightness: Brightness.light,
        ),
        cardTheme: const CardThemeData(
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(16)),
          ),
        ),
      ),
      home: const QuoteFormScreen(),
    );
  }
}

// ==================== QUOTE FORM SCREEN ====================

class QuoteFormScreen extends StatelessWidget {
  const QuoteFormScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Theme.of(context).colorScheme.primary.withOpacity(0.1),
              Theme.of(context).colorScheme.secondary.withOpacity(0.05),
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildAppBar(context),
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      _buildClientInfoCard(context),
                      const SizedBox(height: 16),
                      _buildLineItemsCard(context),
                      const SizedBox(height: 16),
                      _buildTotalsCard(context),
                      const SizedBox(height: 16),
                      _buildActionButtons(context),
                      const SizedBox(height: 32),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAppBar(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Theme.of(context).colorScheme.primary,
            Theme.of(context).colorScheme.secondary,
          ],
        ),
        boxShadow: [
          BoxShadow(
            color: Theme.of(context).colorScheme.primary.withOpacity(0.3),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.2),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(Icons.receipt_long, color: Colors.white, size: 28),
          ),
          const SizedBox(width: 16),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Product Quote Builder',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  'Create professional quotes',
                  style: TextStyle(
                    color: Colors.white70,
                    fontSize: 14,
                  ),
                ),
              ],
            ),
          ),
          Consumer<QuoteProvider>(
            builder: (context, provider, _) => PopupMenuButton<QuoteStatus>(
              icon: const Icon(Icons.more_vert, color: Colors.white),
              itemBuilder: (context) => [
                const PopupMenuItem(
                  value: QuoteStatus.draft,
                  child: Row(
                    children: [
                      Icon(Icons.edit_note, size: 20),
                      SizedBox(width: 8),
                      Text('Draft'),
                    ],
                  ),
                ),
                const PopupMenuItem(
                  value: QuoteStatus.sent,
                  child: Row(
                    children: [
                      Icon(Icons.send, size: 20),
                      SizedBox(width: 8),
                      Text('Sent'),
                    ],
                  ),
                ),
                const PopupMenuItem(
                  value: QuoteStatus.accepted,
                  child: Row(
                    children: [
                      Icon(Icons.check_circle, size: 20),
                      SizedBox(width: 8),
                      Text('Accepted'),
                    ],
                  ),
                ),
              ],
              onSelected: (status) => provider.updateStatus(status),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildClientInfoCard(BuildContext context) {
    final provider = Provider.of<QuoteProvider>(context);
    final quote = provider.currentQuote;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.person, color: Theme.of(context).colorScheme.primary),
                const SizedBox(width: 8),
                const Text(
                  'Client Information',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ],
            ),
            const SizedBox(height: 16),
            TextField(
              decoration: InputDecoration(
                labelText: 'Client Name',
                prefixIcon: const Icon(Icons.badge),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                filled: true,
                fillColor: Theme.of(context).colorScheme.surfaceVariant.withOpacity(0.3),
              ),
              onChanged: provider.updateClientName,
              controller: TextEditingController(text: quote.clientName)
                ..selection = TextSelection.collapsed(offset: quote.clientName.length),
            ),
            const SizedBox(height: 12),
            TextField(
              decoration: InputDecoration(
                labelText: 'Address',
                prefixIcon: const Icon(Icons.location_on),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                filled: true,
                fillColor: Theme.of(context).colorScheme.surfaceVariant.withOpacity(0.3),
              ),
              maxLines: 2,
              onChanged: provider.updateClientAddress,
              controller: TextEditingController(text: quote.clientAddress)
                ..selection = TextSelection.collapsed(offset: quote.clientAddress.length),
            ),
            const SizedBox(height: 12),
            TextField(
              decoration: InputDecoration(
                labelText: 'Reference / PO Number',
                prefixIcon: const Icon(Icons.numbers),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                filled: true,
                fillColor: Theme.of(context).colorScheme.surfaceVariant.withOpacity(0.3),
              ),
              onChanged: provider.updateReference,
              controller: TextEditingController(text: quote.reference)
                ..selection = TextSelection.collapsed(offset: quote.reference.length),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLineItemsCard(BuildContext context) {
    final provider = Provider.of<QuoteProvider>(context);
    final quote = provider.currentQuote;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Icon(Icons.shopping_cart, color: Theme.of(context).colorScheme.primary),
                    const SizedBox(width: 8),
                    const Text(
                      'Line Items',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
                Row(
                  children: [
                    Text(
                      quote.taxMode == TaxMode.inclusive ? 'Tax Inclusive' : 'Tax Exclusive',
                      style: TextStyle(
                        fontSize: 12,
                        color: Theme.of(context).colorScheme.secondary,
                      ),
                    ),
                    Switch(
                      value: quote.taxMode == TaxMode.inclusive,
                      onChanged: (_) => provider.toggleTaxMode(),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 16),
            ...quote.lineItems.map((item) => _buildLineItem(context, item, provider)),
            const SizedBox(height: 12),
            ElevatedButton.icon(
              onPressed: provider.addLineItem,
              icon: const Icon(Icons.add),
              label: const Text('Add Line Item'),
              style: ElevatedButton.styleFrom(
                minimumSize: const Size(double.infinity, 48),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLineItem(BuildContext context, LineItem item, QuoteProvider provider) {
    final currencyFormat = NumberFormat.currency(symbol: '\$', decimalDigits: 2);

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceVariant.withOpacity(0.3),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Theme.of(context).colorScheme.outline.withOpacity(0.2),
        ),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: TextField(
                  decoration: const InputDecoration(
                    labelText: 'Product/Service',
                    isDense: true,
                    border: OutlineInputBorder(),
                  ),
                  onChanged: (value) => provider.updateLineItem(item.id, name: value),
                  controller: TextEditingController(text: item.name)
                    ..selection = TextSelection.collapsed(offset: item.name.length),
                ),
              ),
              const SizedBox(width: 8),
              if (provider.currentQuote.lineItems.length > 1)
                IconButton(
                  icon: const Icon(Icons.delete, color: Colors.red),
                  onPressed: () => provider.removeLineItem(item.id),
                ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: TextField(
                  decoration: const InputDecoration(
                    labelText: 'Qty',
                    isDense: true,
                    border: OutlineInputBorder(),
                  ),
                  keyboardType: TextInputType.number,
                  onChanged: (value) => provider.updateLineItem(
                    item.id,
                    quantity: double.tryParse(value) ?? 0,
                  ),
                  controller: TextEditingController(text: item.quantity.toString())
                    ..selection = TextSelection.collapsed(offset: item.quantity.toString().length),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: TextField(
                  decoration: const InputDecoration(
                    labelText: 'Rate',
                    isDense: true,
                    border: OutlineInputBorder(),
                    prefixText: '\$',
                  ),
                  keyboardType: TextInputType.number,
                  onChanged: (value) => provider.updateLineItem(
                    item.id,
                    rate: double.tryParse(value) ?? 0,
                  ),
                  controller: TextEditingController(text: item.rate.toString())
                    ..selection = TextSelection.collapsed(offset: item.rate.toString().length),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: TextField(
                  decoration: const InputDecoration(
                    labelText: 'Discount',
                    isDense: true,
                    border: OutlineInputBorder(),
                    prefixText: '\$',
                  ),
                  keyboardType: TextInputType.number,
                  onChanged: (value) => provider.updateLineItem(
                    item.id,
                    discount: double.tryParse(value) ?? 0,
                  ),
                  controller: TextEditingController(text: item.discount.toString())
                    ..selection = TextSelection.collapsed(offset: item.discount.toString().length),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: TextField(
                  decoration: const InputDecoration(
                    labelText: 'Tax %',
                    isDense: true,
                    border: OutlineInputBorder(),
                    suffixText: '%',
                  ),
                  keyboardType: TextInputType.number,
                  onChanged: (value) => provider.updateLineItem(
                    item.id,
                    taxPercent: double.tryParse(value) ?? 0,
                  ),
                  controller: TextEditingController(text: item.taxPercent.toString())
                    ..selection = TextSelection.collapsed(offset: item.taxPercent.toString().length),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.primaryContainer,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Item Total:', style: TextStyle(fontWeight: FontWeight.bold)),
                Text(
                  currencyFormat.format(item.total),
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                    color: Theme.of(context).colorScheme.primary,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTotalsCard(BuildContext context) {
    final provider = Provider.of<QuoteProvider>(context);
    final quote = provider.currentQuote;
    final currencyFormat = NumberFormat.currency(symbol: '\$', decimalDigits: 2);

    return Card(
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Theme.of(context).colorScheme.primaryContainer,
              Theme.of(context).colorScheme.secondaryContainer,
            ],
          ),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          children: [
            _buildTotalRow('Subtotal', currencyFormat.format(quote.subtotal)),
            const Divider(height: 20),
            _buildTotalRow('Total Tax', currencyFormat.format(quote.totalTax)),
            const Divider(height: 20, thickness: 2),
            _buildTotalRow(
              'Grand Total',
              currencyFormat.format(quote.grandTotal),
              isGrandTotal: true,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTotalRow(String label, String value, {bool isGrandTotal = false}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: isGrandTotal ? 20 : 16,
            fontWeight: isGrandTotal ? FontWeight.bold : FontWeight.w600,
          ),
        ),
        Text(
          value,
          style: TextStyle(
            fontSize: isGrandTotal ? 24 : 16,
            fontWeight: FontWeight.bold,
            color: isGrandTotal ? Colors.green[700] : null,
          ),
        ),
      ],
    );
  }

  Widget _buildActionButtons(BuildContext context) {
    final provider = Provider.of<QuoteProvider>(context);

    return Column(
      children: [
        ElevatedButton.icon(
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => const QuotePreviewScreen(),
              ),
            );
          },
          icon: const Icon(Icons.preview),
          label: const Text('Preview Quote'),
          style: ElevatedButton.styleFrom(
            minimumSize: const Size(double.infinity, 56),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
        ),
        const SizedBox(height: 12),
        OutlinedButton.icon(
          onPressed: () async {
            await provider.saveQuote();
            if (context.mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Quote saved successfully!'),
                  backgroundColor: Colors.green,
                ),
              );
            }
          },
          icon: const Icon(Icons.save),
          label: const Text('Save Quote'),
          style: OutlinedButton.styleFrom(
            minimumSize: const Size(double.infinity, 56),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
        ),
      ],
    );
  }
}

// ==================== QUOTE PREVIEW SCREEN ====================

class QuotePreviewScreen extends StatelessWidget {
  const QuotePreviewScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<QuoteProvider>(context);
    final quote = provider.currentQuote;
    final currencyFormat = NumberFormat.currency(symbol: '\$', decimalDigits: 2);
    final dateFormat = DateFormat('MMM dd, yyyy');

    return Scaffold(
      appBar: AppBar(
        title: const Text('Quote Preview'),
        actions: [
          IconButton(
            icon: const Icon(Icons.send),
            onPressed: () {
              provider.updateStatus(QuoteStatus.sent);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Quote sent successfully!'),
                  backgroundColor: Colors.green,
                ),
              );
            },
          ),
        ],
      ),
      body: Container(
        color: Colors.grey[100],
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Card(
            elevation: 4,
            child: Container(
              padding: const EdgeInsets.all(32),
              color: Colors.white,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Header
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'QUOTATION',
                            style: TextStyle(
                              fontSize: 32,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 2,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            'Quote #${quote.id.substring(quote.id.length - 6)}',
                            style: TextStyle(
                              fontSize: 14,
                              color: Colors.grey[600],
                            ),
                          ),
                        ],
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 8,
                        ),
                        decoration: BoxDecoration(
                          color: _getStatusColor(quote.status).withOpacity(0.1),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                            color: _getStatusColor(quote.status),
                          ),
                        ),
                        child: Text(
                          quote.status.name.toUpperCase(),
                          style: TextStyle(
                            color: _getStatusColor(quote.status),
                            fontWeight: FontWeight.bold,
                            fontSize: 12,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 32),
                  
                  // Company & Client Info
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'FROM',
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                                color: Colors.grey,
                              ),
                            ),
                            const SizedBox(height: 8),
                            const Text(
                              'Your Company Name',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              '123 Business Street\nCity, State 12345\ncontact@company.com',
                              style: TextStyle(
                                fontSize: 14,
                                color: Colors.grey[700],
                                height: 1.5,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'TO',
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                                color: Colors.grey,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              quote.clientName.isEmpty ? 'Client Name' : quote.clientName,
                              style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              quote.clientAddress.isEmpty ? 'Client Address' : quote.clientAddress,
                              style: TextStyle(
                                fontSize: 14,
                                color: Colors.grey[700],
                                height: 1.5,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 32),
                  
                  // Date & Reference
                  Row(
                    children: [
                      Expanded(
                        child: _buildInfoBox(
                          'Date',
                          dateFormat.format(quote.createdAt),
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: _buildInfoBox(
                          'Reference',
                          quote.reference.isEmpty ? 'N/A' : quote.reference,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 32),
                  
                  // Line Items Table
                  Container(
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey[300]!),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Column(
                      children: [
                        // Table Header
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: Colors.grey[200],
                            borderRadius: const BorderRadius.only(
                              topLeft: Radius.circular(8),
                              topRight: Radius.circular(8),
                            ),
                          ),
                          child: const Row(
                            children: [
                              Expanded(
                                flex: 3,
                                child: Text(
                                  'DESCRIPTION',
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 12,
                                  ),
                                ),
                              ),
                              Expanded(
                                child: Text(
                                  'QTY',
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 12,
                                  ),
                                  textAlign: TextAlign.center,
                                ),
                              ),
                              Expanded(
                                child: Text(
                                  'RATE',
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 12,
                                  ),
                                  textAlign: TextAlign.right,
                                ),
                              ),
                              Expanded(
                                child: Text(
                                  'TAX',
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 12,
                                  ),
                                  textAlign: TextAlign.right,
                                ),
                              ),
                              Expanded(
                                child: Text(
                                  'TOTAL',
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 12,
                                  ),
                                  textAlign: TextAlign.right,
                                ),
                              ),
                            ],
                          ),
                        ),
                        // Table Rows
                        ...quote.lineItems.asMap().entries.map((entry) {
                          final item = entry.value;
                          final isLast = entry.key == quote.lineItems.length - 1;
                          return Container(
                            padding: const EdgeInsets.all(16),
                            decoration: BoxDecoration(
                              border: Border(
                                bottom: isLast
                                    ? BorderSide.none
                                    : BorderSide(color: Colors.grey[300]!),
                              ),
                            ),
                            child: Row(
                              children: [
                                Expanded(
                                  flex: 3,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        item.name.isEmpty ? 'Unnamed Item' : item.name,
                                        style: const TextStyle(
                                          fontWeight: FontWeight.w600,
                                          fontSize: 14,
                                        ),
                                      ),
                                      if (item.discount > 0) ...[
                                        const SizedBox(height: 4),
                                        Text(
                                          'Discount: ${currencyFormat.format(item.discount)}',
                                          style: TextStyle(
                                            fontSize: 12,
                                            color: Colors.grey[600],
                                          ),
                                        ),
                                      ],
                                    ],
                                  ),
                                ),
                                Expanded(
                                  child: Text(
                                    item.quantity.toStringAsFixed(0),
                                    textAlign: TextAlign.center,
                                    style: const TextStyle(fontSize: 14),
                                  ),
                                ),
                                Expanded(
                                  child: Text(
                                    currencyFormat.format(item.rate),
                                    textAlign: TextAlign.right,
                                    style: const TextStyle(fontSize: 14),
                                  ),
                                ),
                                Expanded(
                                  child: Text(
                                    '${item.taxPercent.toStringAsFixed(1)}%',
                                    textAlign: TextAlign.right,
                                    style: const TextStyle(fontSize: 14),
                                  ),
                                ),
                                Expanded(
                                  child: Text(
                                    currencyFormat.format(item.total),
                                    textAlign: TextAlign.right,
                                    style: const TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          );
                        }).toList(),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),
                  
                  // Totals Section
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Container(
                        width: 300,
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: Colors.grey[50],
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: Colors.grey[300]!),
                        ),
                        child: Column(
                          children: [
                            _buildSummaryRow(
                              'Subtotal',
                              currencyFormat.format(quote.subtotal),
                            ),
                            const SizedBox(height: 12),
                            _buildSummaryRow(
                              'Tax',
                              currencyFormat.format(quote.totalTax),
                            ),
                            const Divider(height: 24, thickness: 2),
                            _buildSummaryRow(
                              'TOTAL',
                              currencyFormat.format(quote.grandTotal),
                              isTotal: true,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 32),
                  
                  // Footer
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Colors.blue[50],
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Terms & Conditions',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          '• Payment is due within 30 days\n'
                          '• Please include the quote number with your payment\n'
                          '• Prices are valid for 30 days from the quote date\n'
                          '• All prices are in USD',
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.grey[700],
                            height: 1.6,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),
                  Center(
                    child: Text(
                      'Thank you for your business!',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: Colors.grey[600],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildInfoBox(String label, String value) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey[50],
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.grey[300]!),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label.toUpperCase(),
            style: const TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.bold,
              color: Colors.grey,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            value,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSummaryRow(String label, String value, {bool isTotal = false}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: isTotal ? 18 : 14,
            fontWeight: isTotal ? FontWeight.bold : FontWeight.w600,
          ),
        ),
        Text(
          value,
          style: TextStyle(
            fontSize: isTotal ? 20 : 14,
            fontWeight: FontWeight.bold,
            color: isTotal ? Colors.green[700] : Colors.black,
          ),
        ),
      ],
    );
  }

  Color _getStatusColor(QuoteStatus status) {
    switch (status) {
      case QuoteStatus.draft:
        return Colors.orange;
      case QuoteStatus.sent:
        return Colors.blue;
      case QuoteStatus.accepted:
        return Colors.green;
    }
  }
}